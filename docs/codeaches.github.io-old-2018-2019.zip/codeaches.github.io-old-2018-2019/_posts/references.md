[Open Source JDK 11]: https://jdk.java.net/11
[Apache Maven 3.6.0]: https://maven.apache.org/download.cgi

[Spring Tool Suite 4 IDE]: https://spring.io/tools
[An account on Pivotal Cloud Foundry (PCF)]: https://console.run.pivotal.io/
[PCF CLI account]: https://console.run.pivotal.io/tools
[spring initializr web tool]: https://start.spring.io/

[PGP]: https://central.sonatype.org/pages/working-with-pgp-signatures.html
[gnupg website]: https://www.gnupg.org/ftp/gcrypt/binary/gnupg-w32-2.2.12_20181214.exe
[OSSRH]: https://mvnrepository.com/search?q=codeaches
[OSSRH Guide]: https://central.sonatype.org/pages/ossrh-guide.html#create-a-ticket-with-sonatype
[Sonatype releases]: https://oss.sonatype.org/content/repositories/releases/
[Sonatype snapshots]: https://oss.sonatype.org/content/repositories/snapshots/

[Create your JIRA account]: https://issues.sonatype.org/secure/Signup!default.jspa
[Create a New Project ticket]: https://issues.sonatype.org/secure/CreateIssue.jspa?issuetype=21&pid=10134

[Configuration GIT repository]: https://github.com/codeaches/config-files-example
